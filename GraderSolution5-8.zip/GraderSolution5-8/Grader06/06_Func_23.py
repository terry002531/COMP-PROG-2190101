def main():
    def make_int_list(x):
        return [int(e) for e in x.split()]
    def is_odd(e):
        return e%2 == 1
    def odd_list(alist):
        x = []
        for j in range(len(alist)) :
            if is_odd(alist[j]) :
                x.append(alist[j])
        return x
    def sum_square(alist):
        s2 = []
        for e in alist:
            s2.append(e**2)
        return sum(s2)
        
    exec(input().strip())

main()
