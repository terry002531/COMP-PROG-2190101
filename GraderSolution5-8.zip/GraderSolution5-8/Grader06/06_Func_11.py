def main():
    b1, b2 = input().split()
    n1, n2 = int(b1,2), int(b2,2)
    #print(n1,n2)
    n = n1 + n2
    #print(bin(n))
    b = bin(n)[2:]
    print(b)

main()