students = []
s = 0
filename, year = input().strip().split()
infile = open(filename, "r")
for line in infile:
    id, score = line.split()
    if id [:2] == year [-2:]:
        students.append([float(score),id])
infile.close()
if len(students) == 0:
    print("No data")
else:
    students.sort()
    for [score, id] in students:
        s += score
    print(students[0][0], students[-1][0], s/len(students))



