def rot(st):
    o='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    o_='NOPQRSTUVWXYZABCDEFGHIJKLM'
    answer=''
    for e in (st):
        if 'a'<=e<='z': #or #'A'<=e<='Z':
            answer+=o_.lower()[o.lower().find(e)]
        elif 'A'<=e<='Z':
            answer+=o_[o.find(e)]
        else :
            answer+=e
    print(answer)
a=input()
while a != 'end':
    rot(a)
    a=input()