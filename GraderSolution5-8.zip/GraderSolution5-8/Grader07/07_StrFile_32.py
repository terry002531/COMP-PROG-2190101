def no_lowercase(t): # return True if no lowercase, otherwise return False
    for e in t:
        if "a" <= e <= "z":
            return False
    return True

def no_uppercase(t):
    for e in t:
        if "A" <= e <= "Z":
            return False
    return True

def no_number(t):
    for e in t:
        if "0" <= e <= "9":
            return False
    return True

def no_symbol(t):
    for e in t:
        if e.lower() not in "abcdefghijklmnopqrstuvwxyz0123456789":
            return False
    return True

def character_repetition(t):
    for i in range(len(t)-3):
        if t[i] == t [i+1] == t[i+2] == t[i+3]:
            return True
    return False

def number_sequence(t):
    for i in range(len(t)-3):
        if t[i:i+4] in "01234567890" or t[i:i+4] in "09876543210":
            return True
    return False

def letter_sequence(t):
    for i in range(len(t)-3):
        if t[i:i+4].lower() in "abcdefghijklmnopqrstuvwxyz" or t[i:i+4].lower() in "zyxwvutsrqponmlkjihgfedcba":
            return True
    return False

def keyboard_pattern(t):
    for i in range(len(t)-3):
        if t[i:i+4].lower() in "qwertyuiop" or t[i:i+4].lower() in "poiuytrewq":
            return True
        elif t[i:i+4].lower() in "asdfghjkl" or t[i:i+4].lower() in "lkjhgfdsa":
            return True
        elif t[i:i+4].lower() in "zxcvbnm" or t[i:i+4].lower() in "mnbvcxz":
            return True
        elif t[i:i+4].lower() in "!@#$%^&*()_+" or t[i:i+4].lower() in "+_)(*&^%$#@!":
            return True
    return False
#-----------------------------
passw = input().strip()
errors = []
if len(passw) < 8:
    errors.append("Less than 8 characters")
if no_lowercase(passw):
    errors.append("No lowercase letters")
if no_uppercase(passw):
    errors.append("No uppercase letters")
if no_number(passw):
    errors.append("No numbers")
if no_symbol(passw):
    errors.append("No symbols")
if character_repetition(passw):
    errors.append("Character repetition")
if number_sequence(passw):
    errors.append("Number sequence")
if letter_sequence(passw):
    errors.append("Letter sequence")
if keyboard_pattern(passw):
    errors.append("Keyboard pattern")
if len(errors) == 0:
    print("OK")
else:
    for e in errors:
        print(e)
