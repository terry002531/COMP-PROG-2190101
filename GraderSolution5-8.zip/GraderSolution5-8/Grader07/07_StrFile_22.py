n1 = input()
n2 = input()
ln1 = []
ln2 = []
for e in n1:
    if 'a' <= e <= 'z' or 'A' <= e <= 'Z':
        ln1.append(e.lower())
for e in n2:
    if 'a' <= e <= 'z' or 'A' <= e <= 'Z':
        ln2.append(e.lower())
ln1.sort()
ln2.sort()
if ln1 == ln2:
    print("YES")
else:
    print("NO")
