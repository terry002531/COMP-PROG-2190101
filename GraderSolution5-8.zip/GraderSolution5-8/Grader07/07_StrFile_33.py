fn1, fn2 = input().strip().split()
lines1 = [line.rstrip('\n') for line in open(fn1)]
lines2 = [line.rstrip('\n') for line in open(fn2)]
data = []
def get_data(lines):
  for line in lines:
    sid, gpa = line.strip().split()
    data.append((sid, gpa))
get_data(lines1)
get_data(lines2)
data = sorted(data, key=lambda x: (x[0][-2:], x[0]))
for x in data:
  print(x[0], x[1])
