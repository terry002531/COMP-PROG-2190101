n = input()
temp = ""
for e in n:
    if "0" <= e <= "9" or "a" <= e <= "z" or "A" <= e <= "Z":
        temp += e
    else:
        temp += " "
s = temp.split()
for i in range(len(s)):
    if i == 0:
        s[i] = s[i].lower()
    else:
        s[i] = s[i][0].upper() + s[i][1:].lower()
print("".join(s))
