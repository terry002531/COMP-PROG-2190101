n = input().strip()
com = input().strip()
n = n.upper()
out = ""
a = 0; t = 0; g = 0; c = 0
paircnt = 0
invalid = False
if com == "R":
    for e in n:
        if e == "A":
            out += "T"
        elif e == "T":
            out += "A"
        elif e == "C":
            out += "G"
        elif e == "G":
            out += "C"
        else:
            out = "Invalid DNA"
            invalid = True
            break
    if invalid:
        print (out)
    else:
        print (out[::-1])

if com == "F":
    for e in n:
        if e == "A":
            a += 1
        elif e == "T":
            t += 1
        elif e == "C":
            c += 1
        elif e == "G":
            g += 1
        else:
            out = "Invalid DNA"
            invalid = True
            break
    if invalid:
        print (out)
    else:
        out = "A="+str(a)+", T="+str(t)+", G="+str(g)+", C="+str(c)
        print (out)   
    
if com == "D":
    pair = input().strip()
    for i in range(len(n)-1):
        if n[i] not in "ACGT":
            out = "Invalid DNA"
            invalid = True
            break
        elif n[i:i+2] == pair:
            paircnt += 1
    if n[-1] not in "ACGT":
        out = "Invalid DNA"
        invalid = True
    if invalid:
        print (out)
    else:
        print (paircnt)
            




