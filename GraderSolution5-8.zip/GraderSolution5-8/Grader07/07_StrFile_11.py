n = input()
out = ""
if n[-1] == "s" or n[-1] == "x":
    out = n
    out += "es"
elif n[-2:] == "ch":
    out += n
    out += "es"
elif n[-1] == "y" and n[-2] not in "aeiou":
    out += n[:-1]
    out += "ies"
else:
    out = n
    out += "s"
print(out)
    
