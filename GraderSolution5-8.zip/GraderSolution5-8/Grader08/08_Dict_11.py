def main():
    def reverse( d ): 
        # d เป็น dict ที่ประกันว่า value ไม่ซ่ำกัน
        r = {}
        for k in d:
            r[d[k]] = k
        return r

    def keys(d, v):
        x = []
        for k in d:
            if d[k] == v:
                x.append(k)
        return x

    exec(input().strip())

main()
