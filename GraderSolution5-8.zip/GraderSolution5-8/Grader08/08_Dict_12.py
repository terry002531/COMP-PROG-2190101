n = int(input())
d1 = {}
d2 = {}
for i in range(n):
    na, ni = input().strip().split()
    d1[na] = ni
    d2[ni] = na
    
m = int(input())
for i in range(m):
    n = input()
    if n in d1:
        print(d1[n])
    elif n in d2:
        print(d2[n])
    else:
        print('Not found')
