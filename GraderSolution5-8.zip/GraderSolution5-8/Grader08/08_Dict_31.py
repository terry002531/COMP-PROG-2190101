def total(pocket):
    s = 0
    for m in pocket:
        s += m * pocket[m]
    return s

def take(pocket, money_in):
    for k in money_in:
        if k in pocket:
            pocket[k] += money_in[k]
        else:
            pocket[k] = money_in[k]
    
def pay(pocket, amt):
    money = sorted(pocket, reverse=True)
    paid = {}
    if total(pocket) >= amt:
        for e in money:
            while e <= amt:
                if pocket[e] > 0:
                    paid[e] = paid.get(e, 0) + 1
                    pocket[e] -= 1
                    amt -= e
                if amt == 0 or pocket[e] == 0:
                        break
    return paid

    
exec(input().strip())
