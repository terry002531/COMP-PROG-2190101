keytxt = {'2':'a','22':'b','222':'c','3':'d','33':'e','333':'f',\
          '4':'g','44':'h','444':'i','5':'j','55':'k','555':'l',\
          '6':'m','66':'n','666':'o','7':'p','77':'q','777':'r','7777':'s',\
          '8':'t','88':'u','888':'v','9':'w','99':'x','999':'y','9999':'z',\
          '0':' '}
txtkey = {}
for k in keytxt:
    txtkey[keytxt[k]]=k
    
def text2keys(text):
    out = ''
    for c in text:
        if 'a' <= c.lower() <= 'z' or c == ' ':
            out += txtkey[c.lower()] + ' '
    return out

def keys2text(keys):
    out = ''
    l = keys.split()
    for key in l:
        out += keytxt[key]
    return out

exec(input().strip())
