#08_Dict_★★_Ice_Cream_Sales

prices = {}
n = int(input())
for i in range(n):
    item, price = input().split()
    prices[item] = int(price)
    
sales = {}
for i in prices:
    sales[i] = 0
    
m = int(input())
total = 0
for i in range(m):
    item, num = input().split()

    if item in sales:
        sale = float(num)*prices[item]
        total += sale
        sales[item] += sale
    
#print output
if total == 0: print("No ice cream sales")
else:
    print("Total ice cream sales:", total)
    
    sales_list = []
    for i in sales:
        sales_list.append([-sales[i], i])

    sales_list.sort()
    
    top_sales = [sales_list[0][1]]
    for i in sales_list[1:]:
        if i[0] == sales_list[0][0]:
            top_sales.append(i[1])
        else:
            break
        
    top_sales.sort()
    top_sales = ', '.join(top_sales) 
    print("Top sales:", top_sales)
