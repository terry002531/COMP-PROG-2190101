nametel = {}
telname = {}
n = int(input())
for i in range (n):
    n1, n2, no = input().strip().split()
    nametel[n1+' '+n2] = no
    telname[no] = n1+' '+n2
    
m = int(input())
for i in range(m):
    n = input().strip()
    if n in nametel:
        print (n, '-->', nametel[n])
    elif n in telname:
        print(n, '-->', telname[n])
    else:
        print(n, '--> Not found')
