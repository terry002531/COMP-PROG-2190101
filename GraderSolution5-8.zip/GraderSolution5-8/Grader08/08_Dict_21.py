n = input()
d = {}
l = []
for e in n:
    if 'a' <= e.lower() <= 'z': 
        if e.lower() in d:
            d[e.lower()] += 1
        else:
            d[e.lower()] = 1
for k in d:
    l.append([-d[k],k])
l.sort()
for v,c in l:
    print(c, '->', -v)
