d = input().split()
action = input()

for e in action:
    if e == 'C':
        temp = d[:]
        temp[0:len(d)//2]=d[len(d)//2:]
        temp[len(d)//2:]=d[0:len(d)//2]
        d = temp[:]
    if e == "S":
        temp = []
        for i in range(len(d)):
            if i%2 == 0:
                temp.append(d[i//2])
            else:
                temp.append(d[len(d)//2+i//2])
        d = temp[:]
out = " ".join(d)
print(out)
        
