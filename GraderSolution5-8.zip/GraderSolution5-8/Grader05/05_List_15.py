x = [int(e) for e in input().split()]
x.sort()

#x.append(x[-1] + 1)

temp = [[x[0], 1]]
for i in range(1, len(x)):
    if x[i] == x[i-1]:
        temp[-1][1] += 1   # count
    else:
        print(temp[-1][1])
        temp.append([x[i], temp[-1][1]])
        temp[-1][1] = 1
        
        
print(len(temp))
print([e[0] for e in temp[:10]])

