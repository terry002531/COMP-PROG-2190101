n = int(input())
out = [[0,0,0,0]]*n
for i in range(1,n+1):
    point = input().split()
    [x,y] = [float(e) for e in point]
    dist = (x**2 + y**2)**0.5
    out[i-1] = [dist,i,x,y]
out.sort()
display = '#'+str(out[2][1])+': ('+str(out[2][2])+', '+str(out[2][3])+')'
print(display)

