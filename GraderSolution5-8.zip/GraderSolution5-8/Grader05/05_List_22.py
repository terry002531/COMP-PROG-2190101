def main():
    x = input()
    sids = []
    gs = []
    while x != 'q':
        sid, g = x.split()
        sids.append(sid)
        gs.append(g)
        x = input()
    G = ['F', 'D', 'D+', 'C', 'C+', 'B', 'B+', 'A', 'A']
    for qid in input().split():
        if qid in sids:
            k = sids.index(qid)
            gs[k] = G[G.index(gs[k])+1]
    t = [[sids[i], gs[i]] for i in range(len(sids))]
    t.sort()
    for sid, g in t:
        print(sid, g)

main()
