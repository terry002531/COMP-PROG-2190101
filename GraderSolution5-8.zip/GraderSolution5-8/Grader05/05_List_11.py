x = input()
digits = set([e for e in x if '0' <= e <= '9'])
missing = set('0123456789') - digits
if len(missing) > 0:
  print(','.join(sorted(missing)))
else:
  print('None')