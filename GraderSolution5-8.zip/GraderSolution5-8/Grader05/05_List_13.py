def main():
    d = []
    for i in range(int(input())):
        d.append(int(input()))
    d += [int(e) for e in input().split()]
    e = int(input())
    while e != -1:
        d.append(e)
        e = int(input())
    x = []
    for i in range(len(d)):
        if i%2 == 0:
            x.append(d[i])
        else:
            x.insert(0, d[i])
    print(x)

main()
