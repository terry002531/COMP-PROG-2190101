NO=[]
Grade=["F","D","D+","C","C+","B","B+","A"]
Gr=[]
n=input()
while n!="q":
    n=n.split()
    NO.append(n[0])
    Gr.append(n[1])
    n=input()
z=input().split()
for i in range(len(z)):
    if z[i] in NO :
        a=NO.index(z[i])
        if Gr[a]!="A" :
            Gr[a]=Grade[Grade.index(Gr[a])+1]
for i in range(len(NO)):
    print(NO[i],Gr[i])
