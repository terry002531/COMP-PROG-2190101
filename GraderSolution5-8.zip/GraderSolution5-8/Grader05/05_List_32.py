q = list() # ลิสต์ q ใช้เก็บข้อมูลบัตรคิวที่เหมาะสม
ts = list()
to = list()
total = list()
n = int(input()) # อ่านจ านวนค าสั่ง
test = 0
for k in range(n):
    c = input().split() # อ่านข้อมูลค าสั่ง
    if c[0] == 'reset':
        s = int(c[1])
        i = 0
    elif c[0] == 'new':
        ts.append(int(c[1]))
        q.append(s)
        
        print("ticket", s)
        s += 1
    elif c[0] == 'next':
        test += 1
        x = q.pop(0)
        print("call", x)
        if test>1:
            ts.pop(0)
    elif c[0] == 'order':
        to.append(int(c[1]))
        i = len(to)-1
        total.append(to[i]-ts[0])
        ts.pop(0)
        print("qtime", x, total[i])
        test = 0
    elif c[0] == 'avg_qtime':
        avg = sum(total)/len(total)
        print("avg_qtime", round(avg,4) )
