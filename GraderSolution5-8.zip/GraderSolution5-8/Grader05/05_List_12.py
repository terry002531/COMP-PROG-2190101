real = ['Robert', 'William', 'James', 'John', 'Margaret', 
        'Edward', 'Sarah', 'Andrew', 'Anthony', 'Deborah']
nick = ['Dick', 'Bill', 'Jim', 'Jack', 'Peggy', 
        'Ed', 'Sally', 'Andy', 'Tony', 'Debbie']
for i in range(int(input())):
    x = input()
    if x not in real and x not in nick:
        print('Not found')
    elif x in real:
        print(nick[real.index(x)])
    else:
        print(real[nick.index(x)])

